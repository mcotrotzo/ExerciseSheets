package Exercise3;

public enum ProductState {
    NEW,
    SOLDOUT;
}
