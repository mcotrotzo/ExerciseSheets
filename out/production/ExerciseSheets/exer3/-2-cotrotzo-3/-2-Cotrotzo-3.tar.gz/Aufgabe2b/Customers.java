package Exercise3;

import java.util.List;

public interface Customers {

    void updateProductStates(Product product, ProductState state);
}
