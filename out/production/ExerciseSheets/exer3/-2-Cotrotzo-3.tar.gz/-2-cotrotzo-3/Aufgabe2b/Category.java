package Exercise3;

public enum Category {
    VEGETABLES,
    FRUITS;
}
