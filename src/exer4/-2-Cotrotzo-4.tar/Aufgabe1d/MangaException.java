package exer4.Aufgabe1d;

public class MangaException extends RuntimeException {
    public MangaException(String message) {
        super(message);
    }
}
